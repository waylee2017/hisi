
#ifndef __MSC_GLUE_H__
#define __MSC_GLUE_H__

int msc_proc_create(void *priv);
void msc_proc_destroy(void);

#endif

